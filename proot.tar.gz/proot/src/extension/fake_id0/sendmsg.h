#ifndef FAKE_ID0_SENDMSG_H
#define FAKE_ID0_SENDMSG_H

#include "tracee/tracee.h"
#include "arch.h"

int handle_sendmsg_enter_end(Tracee *tracee, word_t sysnum);

#endif /* FAKE_ID0_SENGMSG_H */
