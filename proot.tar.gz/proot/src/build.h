/* This file is auto-generated, edit at your own risk.  */
#ifndef BUILD_H
#define BUILD_H
#define HAVE_PROCESS_VM
#define HAVE_SECCOMP_FILTER
#endif /* BUILD_H */
